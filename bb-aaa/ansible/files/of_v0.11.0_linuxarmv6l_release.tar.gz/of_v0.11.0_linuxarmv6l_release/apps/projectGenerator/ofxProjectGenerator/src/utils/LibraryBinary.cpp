#include "LibraryBinary.h"

const std::vector<std::string> LibraryBinary::archs{ "x86","Win32","x64","armv7" };
const std::vector<std::string> LibraryBinary::targets{ "Debug","Release" };